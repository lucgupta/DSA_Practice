package AuctionSystem;


import java.util.HashMap;

public class AuctionService {
    private static AuctionService instance = null;

    private AuctionService() {

    }

    public static AuctionService getInstance() {
        if(instance == null)
            instance = new AuctionService();
        return instance;
    }

    BuyerService buyerService = BuyerService.getInstance();

    public HashMap<String, Auction> auctionList = new HashMap<>();

    public Auction createAuction(String auctionId, int low, int high, int cost, String name) {
        Auction auction = new Auction(auctionId, low, high, cost, name);
        auctionList.put(auctionId, auction);
        return auction;
    }

    public String closeAuction(String auction) {
        return "";
    }
}